# StreamMix Mobile Studio
Open this folder in Android Studio (Koala+), let Gradle sync, run on a real Android 10+ phone (emulators have no playback capture).

## What is really captured
- Microphone: yes (AudioRecord + NoiseSuppressor when the device has one).
- Game audio: yes via AudioPlaybackCapture, for games with USAGE_GAME/MEDIA/UNKNOWN audio that allow capture. Games/apps that opt out record silence; the channel shows "CONNECTED · SILENT".
- Discord voice: NOT capturable. Discord plays voice chat as a call stream, which Android excludes from capture. The channel is always shown as BLOCKED; nothing is faked. Workaround: friends' voices played from the speaker leak into the mic (acoustic only, use headphones = they are lost).
- Android may silence the mic while Discord holds it; recording service runs as a microphone foreground service to improve this, but behavior varies by phone.
- Format: WAV 44.1 kHz mono 16-bit. Starting needs MediaProjection consent each session (Android rule), so the overlay can pause/mute/volume but Start opens the app.
