package com.streammix

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.*
import android.media.audiofx.NoiseSuppressor
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.sqrt

/** Shared state: channel 0 = mic, 1 = game, 2 = Discord (never capturable, see status). */
object Engine {
    val gain = MutableStateFlow(listOf(1f, 1f, 1f))
    val mute = MutableStateFlow(listOf(false, false, false))
    val master = MutableStateFlow(1f)
    val level = MutableStateFlow(listOf(0f, 0f, 0f))
    val status = MutableStateFlow(listOf("NOT TESTED", "NOT TESTED", "BLOCKED BY ANDROID"))
    val recording = MutableStateFlow(false)
    val paused = MutableStateFlow(false)
    val elapsedMs = MutableStateFlow(0L)
    fun toggleMic() { mute.value = mute.value.toMutableList().also { it[0] = !it[0] } }
}

class RecService : Service() {
    @Volatile private var run = false
    private var proj: MediaProjection? = null
    private var overlay: View? = null
    private val ui = CoroutineScope(Dispatchers.Main + SupervisorJob())
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        when (i?.action) {
            "start" -> if (!run) start(i)
            "pause" -> Engine.paused.value = !Engine.paused.value
            "stop" -> run = false
        }
        return START_NOT_STICKY
    }

    private fun start(i: Intent) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rec", "Recording", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(this, "rec").setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("StreamMix recording").setOngoing(true).build()
        // Must be foreground (with mediaProjection type) BEFORE getMediaProjection on Android 14+.
        ServiceCompat.startForeground(this, 1, n,
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        proj = mpm.getMediaProjection(i.getIntExtra("code", 0), i.getParcelableExtra("data")!!)
        proj?.registerCallback(object : MediaProjection.Callback() { override fun onStop() { run = false } }, null)
        run = true
        Engine.recording.value = true; Engine.paused.value = false; Engine.elapsedMs.value = 0
        showOverlay()
        Thread { loop() }.start()
    }

    private fun loop() {
        val rate = 44100; val n = 882 // 20 ms frames
        val fmt = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()
        val buf = 8 * AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val mic = try {
            AudioRecord.Builder().setAudioSource(MediaRecorder.AudioSource.MIC).setAudioFormat(fmt)
                .setBufferSizeInBytes(buf).build().also {
                    if (it.state != AudioRecord.STATE_INITIALIZED) error("mic init")
                    if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(it.audioSessionId)
                    it.startRecording()
                }
        } catch (e: Exception) { null }
        val game = try {
            val cfg = AudioPlaybackCaptureConfiguration.Builder(proj!!)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA).addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN).build()
            AudioRecord.Builder().setAudioFormat(fmt).setBufferSizeInBytes(buf)
                .setAudioPlaybackCaptureConfig(cfg).build().also {
                    if (it.state != AudioRecord.STATE_INITIALIZED) error("game init")
                    it.startRecording()
                }
        } catch (e: Exception) { null }
        val dir = getExternalFilesDir("recordings")!!.also { it.mkdirs() }
        val file = File(dir, "StreamMix_${System.currentTimeMillis()}.wav")
        val raf = RandomAccessFile(file, "rw"); raf.write(ByteArray(44))
        val a = ShortArray(n); val b = ShortArray(n); val out = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN)
        var written = 0L; var peakA = 0; var peakB = 0; var frames = 0
        while (run) {
            a.fill(0); b.fill(0)
            mic?.read(a, 0, n); game?.read(b, 0, n)
            val g = Engine.gain.value; val mu = Engine.mute.value; val ms = Engine.master.value
            val ga = if (mu[0]) 0f else g[0]; val gb = if (mu[1]) 0f else g[1]
            var sa = 0.0; var sb = 0.0
            out.clear()
            for (k in 0 until n) {
                val x = a[k] * ga; val y = b[k] * gb
                sa += x * x; sb += y * y
                peakA = maxOf(peakA, abs(a[k].toInt())); peakB = maxOf(peakB, abs(b[k].toInt()))
                out.putShort(((x + y) * ms).coerceIn(-32768f, 32767f).toInt().toShort())
            }
            Engine.level.value = listOf(
                (sqrt(sa / n) / 8000).toFloat().coerceIn(0f, 1f), (sqrt(sb / n) / 8000).toFloat().coerceIn(0f, 1f), 0f)
            if (!Engine.paused.value) { raf.write(out.array(), 0, n * 2); written += n * 2; Engine.elapsedMs.value = written / 2 * 1000 / rate }
            if (++frames % 50 == 0) { // once per second: report real connection state
                Engine.status.value = listOf(
                    if (mic == null) "NOT CONNECTED" else if (peakA > 0) "CONNECTED · LIVE" else "CONNECTED · SILENT",
                    if (game == null) "NOT CONNECTED" else if (peakB > 0) "CONNECTED · LIVE" else "CONNECTED · SILENT (no capturable audio)",
                    "BLOCKED BY ANDROID")
                peakA = 0; peakB = 0
            }
        }
        mic?.release(); game?.release()
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()).putInt((36 + written).toInt()).put("WAVEfmt ".toByteArray()).putInt(16)
            .putShort(1).putShort(1).putInt(rate).putInt(rate * 2).putShort(2).putShort(16)
            .put("data".toByteArray()).putInt(written.toInt())
        raf.seek(0); raf.write(h.array()); raf.close()
        ui.launch { finish() }
    }

    private fun finish() {
        overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }; overlay = null
        proj?.stop(); Engine.recording.value = false; Engine.level.value = listOf(0f, 0f, 0f)
        Engine.status.value = listOf("NOT TESTED", "NOT TESTED", "BLOCKED BY ANDROID")
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }

    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this)) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val p = WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 200 }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 16, 24, 16); setBackgroundColor(0xE61A0B33.toInt()) }
        val t = TextView(this).apply { setTextColor(0xFF00E5FF.toInt()); textSize = 20f; text = "● 00:00 (drag)" }
        val pause = Button(this).apply { text = "⏸ Pause"; setOnClickListener { startService(Intent(context, RecService::class.java).setAction("pause")) } }
        val mic = Button(this).apply { text = "🎤 Mute mic"; setOnClickListener { Engine.toggleMic() } }
        val vol = SeekBar(this).apply { max = 100; progress = 100
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { Engine.master.value = v / 100f }
                override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {} }) }
        box.addView(t); box.addView(pause); box.addView(mic); box.addView(vol)
        var dx = 0f; var dy = 0f
        t.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX - p.x; dy = e.rawY - p.y }
                MotionEvent.ACTION_MOVE -> { p.x = (e.rawX - dx).toInt(); p.y = (e.rawY - dy).toInt(); wm.updateViewLayout(box, p) }
            }; true }
        wm.addView(box, p); overlay = box
        ui.launch {
            launch { Engine.elapsedMs.collect { val s = it / 1000; t.text = "● %02d:%02d (drag)".format(s / 60, s % 60) } }
            launch { Engine.paused.collect { pause.text = if (it) "▶ Resume" else "⏸ Pause" } }
            launch { Engine.mute.collect { mic.text = if (it[0]) "🎤 Unmute mic" else "🎤 Mute mic" } }
        }
    }
}
