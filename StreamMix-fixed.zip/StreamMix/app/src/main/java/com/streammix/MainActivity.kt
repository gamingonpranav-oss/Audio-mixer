package com.streammix

import android.Manifest
import android.content.Intent
import android.media.MediaPlayer
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import java.io.File

val Neon = Color(0xFF00E5FF); val Violet = Color(0xFF7C3AED); val Card = Color(0xFF120A22)

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b); setContent { App() } }

    @Composable fun App() {
        val ctx = this
        val rec by Engine.recording.collectAsState(); val paused by Engine.paused.collectAsState()
        val ms by Engine.elapsedMs.collectAsState(); val master by Engine.master.collectAsState()
        var files by remember { mutableStateOf(listOf<File>()) }
        val player = remember { arrayOf<MediaPlayer?>(null) }
        LaunchedEffect(rec) { files = (getExternalFilesDir("recordings")?.listFiles()?.sortedByDescending { it.lastModified() }) ?: listOf() }
        val proj = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            if (r.resultCode == RESULT_OK) startForegroundService(Intent(ctx, RecService::class.java)
                .setAction("start").putExtra("code", r.resultCode).putExtra("data", r.data))
        }
        val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { ok ->
            if (ok[Manifest.permission.RECORD_AUDIO] == true)
                proj.launch((getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).createScreenCaptureIntent())
        }
        MaterialTheme(colorScheme = darkColorScheme(primary = Neon, secondary = Violet, background = Color.Black, surface = Card)) {
            Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black, Color(0xFF0B0418))))
                .padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("STREAMMIX", color = Neon, fontSize = 26.sp)
                Ch(0, "MICROPHONE"); Ch(1, "GAME AUDIO"); Ch(2, "DISCORD AUDIO", blocked = true)
                Text("MASTER", color = Violet); Slider(master, { Engine.master.value = it })
                Text("%02d:%02d".format(ms / 60000, ms / 1000 % 60), color = Neon, fontSize = 40.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BigBtn(if (rec) "■ STOP" else "● REC", Modifier.weight(1f)) {
                        if (rec) startService(Intent(ctx, RecService::class.java).setAction("stop"))
                        else perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS))
                    }
                    BigBtn(if (paused) "▶ RESUME" else "⏸ PAUSE", Modifier.weight(1f)) {
                        if (rec) startService(Intent(ctx, RecService::class.java).setAction("pause")) }
                }
                if (!Settings.canDrawOverlays(ctx)) OutlinedButton({ startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) },
                    Modifier.fillMaxWidth()) { Text("Allow floating panel (overlay permission)") }
                Text("RECORDINGS", color = Violet)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(files) { f ->
                        Row(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(10.dp)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(f.name.removePrefix("StreamMix_"), Modifier.weight(1f), fontSize = 12.sp)
                            TextButton({ player[0]?.release(); player[0] = MediaPlayer().apply { setDataSource(f.path); prepare(); start() } }) { Text("▶") }
                            TextButton({ val u = FileProvider.getUriForFile(ctx, "$packageName.fp", f)
                                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("audio/wav").putExtra(Intent.EXTRA_STREAM, u)
                                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Export")) }) { Text("Export") }
                            TextButton({ f.delete(); files = files - f }) { Text("✕") }
                        }
                    }
                }
            }
        }
    }

    @Composable fun Ch(i: Int, name: String, blocked: Boolean = false) {
        val g by Engine.gain.collectAsState(); val mu by Engine.mute.collectAsState()
        val lv by Engine.level.collectAsState(); val st by Engine.status.collectAsState()
        val l by animateFloatAsState(lv[i])
        Column(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(14.dp)).padding(12.dp)) {
            Row { Text(name, color = Neon, modifier = Modifier.weight(1f))
                Text(st[i], fontSize = 11.sp, color = if (st[i].startsWith("CONNECTED")) Color(0xFF39FF14) else Color(0xFFFF5370)) }
            LinearProgressIndicator({ l }, Modifier.fillMaxWidth().height(10.dp), color = if (l > .85f) Color.Red else Neon)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Slider(g[i], { Engine.gain.value = g.toMutableList().also { x -> x[i] = it } }, Modifier.weight(1f), enabled = !blocked, valueRange = 0f..2f)
                Button({ Engine.mute.value = mu.toMutableList().also { x -> x[i] = !x[i] } }, enabled = !blocked,
                    colors = ButtonDefaults.buttonColors(containerColor = if (mu[i]) Color.Red else Violet)) { Text(if (mu[i]) "MUTED" else "MUTE") }
            }
            if (blocked) Text("Discord voice uses a protected audio stream that Android does not let apps capture.", fontSize = 11.sp, color = Color.Gray)
        }
    }

    @Composable fun BigBtn(t: String, m: Modifier, onClick: () -> Unit) =
        Button(onClick, m.height(64.dp), colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Text(t, fontSize = 18.sp) }
}
